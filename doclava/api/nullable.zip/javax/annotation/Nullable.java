// empty placeholder definition to satisfy javadoc
package javax.annotation; public @interface Nullable {}
